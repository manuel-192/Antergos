# Antergos-bot
Antergos Telegram Bot

Telegram Bot that forwards Antergos alerts to a Telegram channel

[Antergos Alerts Channel](http://t.me/antergos_alerts)

## Dependencies

[python-telegram-bot](https://github.com/python-telegram-bot/python-telegram-bot)
