The inspiration for this theme is the [Numix Project](https://github.com/numixproject).
