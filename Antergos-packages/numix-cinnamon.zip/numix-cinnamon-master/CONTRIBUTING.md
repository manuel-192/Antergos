* In case you want to contribute code, __don't edit the css file!__ Instead, edit the relevant sass files(s) and compile to css.

* This is a very opinionated project, so try to avoid suggesting visual changes. :grinning:
