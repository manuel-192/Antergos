# oblogout Numix theme

Icon theme for oblogout

Install icons into /usr/share/themes/Numix/oblogout

Edit /etc/oblogout.conf and in section [looks] set buttontheme = Numix

![cancel.svg](cancel.svg)
![hibernate.svg](hibernate.svg)
![lock.svg](lock.svg)
![logout.svg](logout.svg)
![restart.svg](restart.svg)
![shutdown.svg](shutdown.svg)
![suspend.svg](suspend.svg)
![switch.svg](switch.svg)
