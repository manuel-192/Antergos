![screenshot](https://raw.github.com/jkw/antergos-welcome/master/screenshot.png)

antergos-welcome
================

Antergos welcome screen

* python (python3)
* python-simplejson
* python-gobject
* python-pydbus
* notification-daemon
* webkit2gtk


