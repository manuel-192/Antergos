TODO
====

TODO list for Antergos projects

### Cnchi
