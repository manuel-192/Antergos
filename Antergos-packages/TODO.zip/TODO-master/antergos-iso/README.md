# ANTERGOS-ISO TODO LIST

## Release Blockers
 - [ ] Port UEFI changes from port-upstream-changes branch to master. (Most importantly, Preloader)

## Minimal Branch
 - [ ] Create custom faenza-icon-theme package just with necesary icons for Cnchi
 - [ ] Develop the connection window to allow users to configure their internet connection inside Cnchi
