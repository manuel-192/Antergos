# Antergos alpm hooks

A collection of Antergos alpm hooks.

See https://www.archlinux.org/pacman/alpm-hooks.5.html for more info.
