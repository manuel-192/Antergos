installation.mkinitcpio
=======================

.. automodule:: installation.mkinitcpio
   :members:
