installation.boot (module)
==========================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   installation_boot_grub2
   installation_boot_loader
   installation_boot_refind
   installation_boot_systemd_boot
