desktop_info
============

.. automodule:: desktop_info
   :members:
