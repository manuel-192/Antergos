installation.boot.refind
========================

.. automodule:: installation.boot.refind
   :members:
