installation.install
====================

.. automodule:: installation.install
   :members:
