misc.extra
==========

.. automodule:: misc.extra
   :members:
