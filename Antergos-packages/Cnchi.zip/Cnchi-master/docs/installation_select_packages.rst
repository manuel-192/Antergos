installation.select_packages
============================

.. automodule:: installation.select_packages
   :members:
