browser_window
==============

.. automodule:: browser_window
   :members:
