misc.avatars
============

.. automodule:: misc.avatars
   :members:
