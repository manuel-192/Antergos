info
====

.. automodule:: info
   :members:
