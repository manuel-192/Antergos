installation.lamp
=================

.. automodule:: installation.lamp
   :members:
