misc.run_cmd
============

.. automodule:: misc.run_cmd
   :members:
