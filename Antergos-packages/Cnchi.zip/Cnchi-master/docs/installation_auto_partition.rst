installation.auto_partition
===========================

.. automodule:: installation.auto_partition
   :members:
