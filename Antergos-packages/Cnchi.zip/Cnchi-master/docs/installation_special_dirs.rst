installation.special_dirs
=========================

.. automodule:: installation.special_dirs
   :members:
