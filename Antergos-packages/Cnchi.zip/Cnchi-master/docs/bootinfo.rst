bootinfo
========

.. automodule:: bootinfo
   :members:
