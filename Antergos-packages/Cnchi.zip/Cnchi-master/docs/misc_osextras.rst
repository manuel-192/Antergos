misc.osextras
=============

.. automodule:: misc.osextras
   :members:
