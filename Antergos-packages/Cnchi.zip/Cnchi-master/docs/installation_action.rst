installation.action
===================

.. automodule:: installation.action
   :members:
