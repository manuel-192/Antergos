
import LanguagePage from './01-Language/LanguagePage';

const all_pages = {
	LanguagePage,
};

export { all_pages as default };