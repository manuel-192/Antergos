#!/bin/sh
python -m compileall /usr/share/cnchi
