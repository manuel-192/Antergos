#!/bin/sh
sudo pacman -S gtk3 python3 python-cairo python-dbus python-gobject python-mako pyparted pyalpm webkitgtk hdparm upower python-requests


