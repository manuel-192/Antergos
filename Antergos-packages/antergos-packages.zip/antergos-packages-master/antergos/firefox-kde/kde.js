pref("browser.preferences.instantApply", false);
