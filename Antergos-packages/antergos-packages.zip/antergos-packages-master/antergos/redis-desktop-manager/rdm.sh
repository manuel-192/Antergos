#!/bin/bash
DIR=$(dirname "$(readlink -f "$0")")
$DIR/rdm
