#!/bin/sh

/opt/gitkraken/gitkraken "$@"
