# iso-hotfix-utility
Make changes to linux live install media on-the-fly when the media is booted.
