# NodeBB SSO Auth0
[![npm](https://img.shields.io/npm/v/nodebb-plugin-sso-auth0.svg?style=flat-square&maxAge=604800)](https://www.npmjs.com/package/nodebb-plugin-sso-auth0) &nbsp;[![npm](https://img.shields.io/npm/dm/nodebb-plugin-sso-auth0.svg?style=flat-square)]()

Auth0 integration for NodeBB

## Requirements
* NodeJS 7.10+

## Installation
### UI
NodeBB Admin &Gt; Plugins &Gt; Install Plugins
### Command Line
```sh
npm install nodebb-plugin-sso-auth0
```
