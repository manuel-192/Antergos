# antergos-kde-setup
Antergos setup for KDE
