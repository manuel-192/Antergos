# Status Menu Buttons

A **GNOME Shell Extension** that adds a hibernate, suspend, & lock button to the status menu.

### Dependancies
* LightDM
* [light-locker](https://github.com/the-cavalry/light-locker)

 
### Optional
* [light-locker-settings](https://launchpad.net/light-locker-settings)

