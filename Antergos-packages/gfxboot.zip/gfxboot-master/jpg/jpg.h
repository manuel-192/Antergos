int jpeg_decode(unsigned char *jpg, unsigned char *img, int x_0, int x_1, int y_0, int y_1, int color_bits);
unsigned jpeg_get_size(unsigned char *buf);
