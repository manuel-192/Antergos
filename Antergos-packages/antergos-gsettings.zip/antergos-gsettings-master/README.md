# antergos-gsettings
Default Setup for Antergos GTK3 Desktops
