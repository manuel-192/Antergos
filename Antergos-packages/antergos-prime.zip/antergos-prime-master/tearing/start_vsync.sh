#!/bin/sh

##
# Enable Prime Synchronization
## 

# Replace "eDP-1-1" with the name of your screen

xrandr --output eDP-1-1 --set "PRIME Synchronization" 1


