# grub2-theme-antergos
Antergos default Grub2 theme
