# antergos-repo-priority
Automatically adjusts the priority of the antergos repo in pacman.conf as needed.
