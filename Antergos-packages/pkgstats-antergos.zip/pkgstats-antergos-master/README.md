# pkgstats-antergos
Submits a list of installed packages to the Antergos and Arch Linux projects
