antergos-slim-theme
===================

Antergos branded theme for the SLiM login manager
