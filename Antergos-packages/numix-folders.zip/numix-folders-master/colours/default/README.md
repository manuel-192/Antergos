You can use any styles default colours by choosing `style{#}` as colour option, when running the script.
