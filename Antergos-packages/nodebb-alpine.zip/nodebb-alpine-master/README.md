# nodebb-alpine
Docker image for deploying NodeBB. Currently using it for https://forum.antergos.com
