#!/bin/bash
set -e

cabal update
