#!/usr/bin/env escript

-module('hello-world').

main(_) ->
  io:format("Hello World!~n").
