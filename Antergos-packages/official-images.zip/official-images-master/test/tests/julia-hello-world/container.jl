println("Hello World!");

# https://github.com/docker-library/julia/pull/6
download("https://google.com");

# https://github.com/docker-library/julia/pull/9
Pkg.add("JSON");
