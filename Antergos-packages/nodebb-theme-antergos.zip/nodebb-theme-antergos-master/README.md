Antergos Theme for NodeBB
=========================

Based on Lavender NodeBB theme:

https://github.com/NodeBB/nodebb-theme-lavender
