LogServer
=========

Antergos LogServer to store cnchi's logs at request to be examined
