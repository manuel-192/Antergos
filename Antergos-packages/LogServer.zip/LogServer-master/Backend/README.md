LogServer
=========

Antergos LogServer BackEnd

# Dependencies
* mongodb
* mongojs
* request
