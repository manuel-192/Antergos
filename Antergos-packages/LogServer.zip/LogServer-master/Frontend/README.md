LogServer
=========

Antergos LogServer FrontEnd

# Dependencies
* express
* jade
* mongodb
* mongoskin
