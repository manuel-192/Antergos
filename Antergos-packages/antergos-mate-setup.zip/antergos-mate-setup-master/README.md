# antergos-mate-setup
Antergos MATE default configuration
