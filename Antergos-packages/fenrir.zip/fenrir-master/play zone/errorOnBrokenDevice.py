#!/bin/python

# in case that event13 is still the broken device
f = open('/dev/input/event13')
print('OK /dev/input/event13')
