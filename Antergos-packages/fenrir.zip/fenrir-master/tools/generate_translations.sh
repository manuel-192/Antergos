#!/usr/bin/env bash

pygettext3 -d fenrir ../src/fenrir/*.py ../src/fenrir/*/*.py ../src/fenrir/*/*/*.py
