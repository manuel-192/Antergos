# cnchi-bugsnag
Cnchi ![issues](https://github.com/antergos/cnchi-bugsnag/issues) reported by bugsnag
