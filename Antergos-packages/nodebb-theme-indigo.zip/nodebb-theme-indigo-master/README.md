# nodebb-theme-indigo
A modern theme for NodeBB inspired by Lavender, built with ReactJS.
