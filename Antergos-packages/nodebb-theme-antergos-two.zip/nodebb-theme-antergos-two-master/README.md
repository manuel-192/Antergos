## nodebb-theme-antergos-two
##### Theme for NodeBB using Google Material Design

### Installation

    * Install this theme using the "Plugins" page in NodeBB ACP
    
    * After installation switch to the theme using the "Themes" page in ACP
    
    * Restart NodeBB


### Credits

* Animate.css - http://daneden.me/animate
* Waves by Alfiana E. Sibuea http://fian.my.id/Waves 
* nodebb-theme-material by @pichalite
* nodebb-theme-persona by @NodeBB